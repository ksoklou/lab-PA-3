import React, { Component } from "react";
 
class Home extends Component {
  render() {
    return (
      <div>

        <img src="/Capture.PNG" alt=""/>
 
      </div>
    );
  }
}
 
export default Home;
