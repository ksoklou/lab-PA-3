import React, { Component } from "react";
 
class About  extends Component {
  render() {
    return (
      <div>

        <img src="/Capture1.PNG" alt=""/>
 
      </div>
    );
  }
}
 
export default About ;