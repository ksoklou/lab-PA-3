import React, { Component } from "react";
 
class Products  extends Component {
  render() {
    return (
      <div>

        <img src="/Capture2.PNG" alt=""/>
        <h2>You can place your order </h2>
        <p>by Phone: 757 -345-8763 </p>
        <p> by Email Ethelsbananapudding@yahoo.com </p>
        <p>  <a href="https://www.instagram.com/ethelsbananapudding/?hl=en"> Instagram </a> </p>
        <p>  <a href="https://ethelspudding.com/"> Website</a> </p>
        <p> 
          <a href="https://www.google.com/maps/place/Virginia+Beach+Farmers+Market/@36.7767557,
          -76.0934332,17z/data=!3m1!4b1!4m5!3m4!1s0x89babf8227b03689:0xb6ff555ecc2d3553!8m2!3d36.
          7767557!4d-76.0912445"> We at Virginia Beach farmers market every weekend </a> </p>

        <h2>
        </h2>
 
      </div>
    );
  }
}
 
export default Products ;